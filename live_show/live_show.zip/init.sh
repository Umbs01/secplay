#!/bin/bash
touch /flag.txt
echo ${FLAG} > /flag.txt

python3 app.py